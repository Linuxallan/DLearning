from alphafold2_pytorch.alphafold2 import Alphafold2, Evoformer
